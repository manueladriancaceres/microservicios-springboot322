package com.example.creditos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoCreditosApplicationTests {

	@Test
	void contextLoads() {
	}

}
