package com.example.usuario.usuariocommons;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsuariocommonsApplicationTests {

	@Test
	void contextLoads() {
	}

}
